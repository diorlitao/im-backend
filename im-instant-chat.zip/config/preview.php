<?php
return [
    'own'=>env('preview.own', ''),
    'yzdcs'=>env('preview.yzdcs', ''),
    'keycode'=>env('preview.keycode', ''),
];