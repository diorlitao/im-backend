<?php
// 短信信息配置
return [
    'app_key'       => '', //阿里大于账号的appkey
    'app_secret'       => '', //阿里大于账号的app_secret
    'app_sign'       => '', //公司的签名信息
];