#!/bin/bash
php start.php start -d;
